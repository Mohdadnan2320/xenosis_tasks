import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js'
import { getDatabase, set, ref } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyBc5rrSzQ6n4tzu4DwsjSQ3i7-metW6-Bs",
    authDomain: "user-authentication-ui-8c39a.firebaseapp.com",
    projectId:"user-authentication-ui-8c39a",
    storageBucket:"user-authentication-ui-8c39a.appspot.com",
    messagingSenderId: "574387214425",
    appId: "1:574387214425:web:61326dc1d04b635c31b948"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getDatabase();


function showMessage(message, divId) {
    var messageDiv = document.getElementById(divId);
    messageDiv.style.display = 'block'
    messageDiv.innerHTML = message;
    messageDiv.style.opacity = 1
    setTimeout(function () {
        messageDiv.style.opacity = 0
    }, 4000)
}

//CFREATE ACCOUNT
const signUp = document.getElementById('submitSignUp');
signUp.addEventListener('click', function (event) {
    event.preventDefault();
    const email = document.getElementById('rEmail').value;
    const username = document.getElementById('rUsername').value;
    const password = document.getElementById('rPassword').value;


    if(email.length && username.length && password.length > 1){
        
        createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            set(ref(db,'UserAuthList/' + userCredential.user.uid),{
                email:email,
                username:username
            })
            
            showMessage('Acoount Created Successfully', 'signUpMessage');
        })
        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            showMessage(error.message, 'signUpMessage');

        });
        
    }else{
        showMessage('Please fill the details', 'signUpMessage');

    }

   

})

//PASSWORD STRENGTH

var msg = document.getElementById('message');
var str = document.getElementById('strength');
var pass = document.getElementById('rPassword');

pass.addEventListener('input', ()=>{
    if(pass.value.length >0){
        if(pass.value.length < 4){
            msg.style.display = 'block'
            str.innerHTML = "weak"
            pass.style.borderColor = '#ff5925'
            msg.style.color = '#ff5925'
        }
        else if(pass.value.length >= 4 && pass.value.length < 8){
            msg.style.display = 'block'

            str.innerHTML = "medium"
            pass.style.borderColor = 'yellow'
            msg.style.color = 'yellow'
        }
        else if(pass.value.length >= 8){
            msg.style.display = 'block'

            str.innerHTML = "strong"
            pass.style.borderColor = '#26d730'
            msg.style.color = '#26d730'
        }
    }
    else{
        msg.style.display = 'none'
        pass.style.color = 'none'
        pass.style.borderColor = 'rgb(226, 226, 226)'
    }
    
})


//ClEAR FIELD

function ClearField(){
    email.innerHTML = '';
    username.innerHTML = ''
    password.innerHTML = ''
}